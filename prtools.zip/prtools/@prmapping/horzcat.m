%HORZCAT Mapping overload 
%
%	Horizontal concatenation of mappings is performed by STACKED.
