%UMINUS Mapping overload
