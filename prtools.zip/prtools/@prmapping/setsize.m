%SETSIZE Set size_in as well as size_out field in mapping
%
%    W = SETSIZE(W,SIZE)
%
% Sets SIZE_IN = SIZE(1) and SIZE_OUT = SIZE(2), assuming both are
% scalars. If not, use SETSIZE_IN and SETSIZE_OUT
