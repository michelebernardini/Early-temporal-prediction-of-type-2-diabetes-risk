%POWER Mapping overload
