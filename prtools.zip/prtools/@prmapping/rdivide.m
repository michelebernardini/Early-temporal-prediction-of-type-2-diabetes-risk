%RDIVIDE Mapping overload
