%OR Mapping overload
