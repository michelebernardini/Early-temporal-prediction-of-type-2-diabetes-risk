%PLUS Mapping overload
