%PLOTSOM Plot the Self-Organizing Map in 2D
%
%    PLOTSOM(W)
%
% Plot the Self-Organizing Map W, trained by som.m. This is only
% possible if the map is 2D.
%
% SEE ALSO (<a href="http://37steps.com/prtools">PRTools Guide</a>)
% SOM
