%LDIVIDE Mapping overload
