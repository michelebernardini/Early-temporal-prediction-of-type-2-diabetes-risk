%ISEMPTY Test on empty ammping
%
%    I = ISEMPTY(W)
%
% True if the mapping W is empty
