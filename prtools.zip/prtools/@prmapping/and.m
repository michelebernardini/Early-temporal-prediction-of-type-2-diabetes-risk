%AND Mapping overload
