%GETSIZE_IN Get size_in field of mapping
%
%    SIZE_IN = GETSIZE_IN(W)
