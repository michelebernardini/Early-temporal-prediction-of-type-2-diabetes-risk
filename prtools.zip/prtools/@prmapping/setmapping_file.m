%SETMAPPING_FILE Set filename of routine that defines or executes a mapping
%
%    W = SETMAPPING_FILE(W,MAPPING_FILE)
