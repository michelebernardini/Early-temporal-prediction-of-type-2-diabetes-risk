%ISAFFINE Test affine mapping
%
%    I = ISAFFINE(W)
%    ISAFFINE(W)
%
% I is true if W is an affine mapping.
% If called without an output argument ISAFFINE generates an error
% if W is not an affine mapping.
