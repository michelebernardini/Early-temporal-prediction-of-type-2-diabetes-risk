%GETMAPPING_TYPE Get mapping_type field in mapping
%
%     MAPPING_TYPE = GETMAPPING_TYPE(W)
%
% See HELP MAPPING_TYPE for more onformation on mapping types.
