%EQ Mapping overload
