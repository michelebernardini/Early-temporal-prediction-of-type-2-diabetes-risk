%GT Mapping overload
