%SETNAME Set name field in mapping
%
%    W = SETNAME(W,NAME)
