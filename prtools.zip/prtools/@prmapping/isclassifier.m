%ISCLASSIFIER Test on normed classifier
%
%    I = ISCLASSIFIER(W)
%    ISCLASSIFIER(W)
%
% A mapping W is a classifier if its OUT_CONV field is larger 
% than zero. In that case confidences will be returned.If called
% without an output argument ISCLASSIFIER generates an error
% if W is not a classifier.
