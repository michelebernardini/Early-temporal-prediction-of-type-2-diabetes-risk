%SETSIZE_OUT Set size_out field (output dimensionality) in mapping
%
%    W = SETSIZE_OUT(W,SIZE_OUT)
