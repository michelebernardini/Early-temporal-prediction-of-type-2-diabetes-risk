%XOR Mapping overload
