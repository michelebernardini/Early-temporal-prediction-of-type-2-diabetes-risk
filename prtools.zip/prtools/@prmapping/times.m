%TIMES Mapping overload
