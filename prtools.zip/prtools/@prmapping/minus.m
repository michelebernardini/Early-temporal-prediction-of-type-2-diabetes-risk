%MINUS Mapping overload
