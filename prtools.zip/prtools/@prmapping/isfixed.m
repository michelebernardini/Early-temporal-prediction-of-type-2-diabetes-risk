%ISFIXED Test on fixed mapping
%
%    I = ISFIXED(W)
%    ISFIXED(W)
%
% True if the mapping type of W is 'fixed' (see HELP MAPPINGS). If called
% without an output argument ISFIXED generates an error if the mapping type
% of W is not 'fixed'.
