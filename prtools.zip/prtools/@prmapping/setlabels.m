%SETLABELS Reset labels of mapping
%
%    W = SETLABELS(W,LABELS,J)
%
% Resets the LABELS field of the mapping W. If the index vector J
% is given, just the corresponding labels are updated.
