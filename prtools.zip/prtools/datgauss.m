%DATGAUSS Apply Gaussian filter on images in a dataset
%
% This command is deprecated, use IM_GAUSS instead.

function a = datgauss(varargin)

  a = im_gauss(varargin{:});

return
