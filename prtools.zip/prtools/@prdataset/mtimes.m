%MTIMES Dataset overload of *
%
%    C = A*B
%
% This routines handles the dataset multiplication in case A or B is
% a dataset and none of these is a mapping. A or B may be a cell array
% of datasets as well as a scalar. 
