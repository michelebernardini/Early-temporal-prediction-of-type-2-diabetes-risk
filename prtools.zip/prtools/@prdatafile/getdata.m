%GETDATA Get data of datafile
