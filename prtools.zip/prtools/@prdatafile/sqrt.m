%SQRT Datafile overload
