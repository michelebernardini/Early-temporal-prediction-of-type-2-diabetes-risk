%SETDATASET Set DATASET datafile field
