%SUBSREF Subscripted reference. Datafile overload
%
% 
% $Id: subsref.m,v 1.8 2009/02/19 12:34:02 duin Exp $
