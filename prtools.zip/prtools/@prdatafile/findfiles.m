%FINDFILES   
%
%	J = FINDFILES(A,DIR,FILES)
%
% Find in datafile A the objects that are related to the files listed in
% the character array or cell array FILES stored in the subdirectory DIR
% (usually the class name).
