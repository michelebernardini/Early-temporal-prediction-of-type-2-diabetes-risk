%GT Datafile overload
