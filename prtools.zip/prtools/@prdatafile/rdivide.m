%RDIVIDE Datafile overload
